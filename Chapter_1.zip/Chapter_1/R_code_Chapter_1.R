################################################################################
#               Decomposition of the BSE Mid-Cap Sector Monthly                   # 
#              Index Time Series. Period: Jan 2010 - Dec 2021                  #
################################################################################

mc <- scan("midcap_2010_2021.txt")
mc <- round(mc)
mc
max <- max(mc)
max
min <- min(mc)
min
mc_ts <- ts(mc, frequency=12, start=c(2010,1))
mc_ts
plot(mc_ts, xlab="Year", ylab="Mid-cap Sector Index",ylim=c(4500,30000), 
     lwd=1.5, lty=1, type='l')
mc_ts <- round(mc_ts)
mc_ts

mc_ts_components <- decompose(mc_ts)
mc_ts_components
plot(mc_ts_components, xlab="Year", lwd=2)

mc_ts_components$trend <- round(mc_ts_components$trend)
mc_ts_components$trend
mc_ts_components$seasonal <- round(mc_ts_components$seasonal)
mc_ts_components$seasonal
mc_ts_components$random <- round(mc_ts_components$random)
mc_ts_components$random

###############################################################################
#               The statistics of the seasonality component                   #
###############################################################################
mc_ts
x <- mc_ts_components$seasonal
x <- abs(x)
pc_season <- (x/mc_ts)*100
pc_season_max <- max(pc_season)
pc_season_max
pc_season_min <- min(pc_season)
pc_season_min
pc_avg <- mean(pc_season_min)
pc_avg
pc_sd <- sd(pc_season)
pc_sd

which(pc_season==pc_season_max) #  Dec 2011
which(pc_season==pc_season_min) #  July 2021

################################################################################
#               The statistics of the trend component                          #
################################################################################
mc_ts
length(mc_ts)
y <- mc_ts_components$trend
length(y)
pc_trend <- (y/mc_ts)*100
pc_trend <- na.omit(pc_trend)
pc_trend_max <- max(pc_trend)
pc_trend_max
pc_trend_min <- min(pc_trend)
pc_trend_min
pc_trend_avg <- mean(pc_trend)
pc_trend_avg
pc_trend_sd <- sd(pc_trend)
pc_trend_sd

which(pc_trend==pc_trend_max) # Mar 2020
which(pc_trend==pc_trend_min) # Jan 2020

################################################################################
#               The statistics of the random component                          #
################################################################################
mc_ts
length(mc_ts)
y <- mc_ts_components$random
y <- abs(y)
length(y)
max(na.omit(y))
min(na.omit(y))
pc_random <- (y/mc_ts)*100
pc_random <- na.omit(pc_random)
pc_random_max <- max(pc_random)
pc_random_max
pc_random_min <- min(pc_random)
pc_random_min
pc_random_avg <- mean(pc_random)
pc_random_avg
pc_random_sd <- sd(pc_random)
pc_random_sd

which(pc_random==pc_random_max) # Mar 2020
which(pc_random==pc_random_min) # Jan 2020

################################################################################ 
#                 Method 1 : HoltWinters with horizon = 12                     #
################################################################################
library(forecast)
mc_train <- mc[1:132]
mc_train
mc_train_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_train_ts
mc_train_ts_hw <- HoltWinters(mc_train_ts)
mc_train_ts_hw
mc_train_ts_hw$fitted
plot(mc_train_ts_hw$fitted)
mc_train_ts_hw$SSE

mc_ts_hw_forecasts <- forecast:::forecast.HoltWinters(mc_train_ts_hw, h=12)
mc_ts_hw_forecasts

# Residual autocorrelation analysis on the in-sample data
mc_ts_hw_forecasts$residuals
mc_ts_hw_forecasts$residuals <- mc_ts_hw_forecasts$residuals[-1:-12]
mc_ts_hw_forecasts$residuals
acf(mc_ts_hw_forecasts$residuals, lag.max=12)
acf(mc_ts_hw_forecasts$residual, lag.max=12, plot=FALSE)


Box.test(mc_ts_hw_forecasts$residuals, lag=24, type="Ljung-Box")
# Ho assumes that there is no autocorrelation among the residuals. Ho gets a 
# support as the p-value of the test is 0.324.

library(Metrics)

actual <- mc[133:144]
actual
predicted <- scan("Method_1/predicted_2021_method_I.txt")
predicted <- round(predicted)
predicted
x <- rmse(actual,predicted)
x
y <- mean(actual)
y
z <- (x/y)*100
z
w <- mape(actual,predicted)
w

t <- abs((actual-predicted)/actual)*100
t

plot(actual, xlab="Months of 2021", ylab="Mid-cap Sector Index", 
     xlim=c(1, length(actual)), ylim=c(15000,30000), lwd=2, lty=1, 
     col="blue", type='l')
lines(predicted, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), 
       cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
title("Forecasting of the Mid-cap Sector Index Using Method I")


################################################################################ 
#                 Method 2: HoltWinters with horizon = 1                       #
################################################################################

mc <- scan("midcap_2010_2021.txt")
mc <- round(mc)
mc_train <- mc[1:132]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Feb 2021 #
mc_train <- mc[1:133]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Mar 2021 #
mc_train <- mc[1:134]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Apr 2021 #
mc_train <- mc[1:135]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for May 2021 #
mc_train <- mc[1:136]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Jun 2021 #
mc_train <- mc[1:137]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Jul 2021 #
mc_train <- mc[1:138]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Aug 2021 #
mc_train <- mc[1:139]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Sep 2021 #
mc_train <- mc[1:140]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Oct 2021 #
mc_train <- mc[1:141]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Nov 2021 #
mc_train <- mc[1:142]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts

# Forecasting for Dec 2021 #
mc_train <- mc[1:143]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_hw <- HoltWinters(mc_ts)
mc_hw_forecasts <- forecast:::forecast.HoltWinters(mc_hw, h=1)
mc_hw_forecasts


library(Metrics)
actual <- mc[133:144]
predicted <- scan("Method_2/predicted_2021_method_II.txt")
predicted <- round(predicted)
predicted
x <- rmse(actual,predicted)
x
y <- mean(actual)
y
z <- (x/y)*100
z
w <- mape(actual,predicted)
w

t <- abs((actual-predicted)/actual)*100
t

residuals <- (actual-predicted) 
residuals
acf(residuals, lag.max=12, lwd = 1.5, main = "ACF Plot of Residuals 
    for Method II")
acf(residuals, lag.max=12, plot=FALSE, main= "ACF Plot of the Resuduals for 
    Method II")
Box.test(residuals, lag=11, type="Ljung-Box")
# Ho has a p-value of 0.2241 impying sufficient support for it. H0 assumes 
#that there is no significant autocorrelation among the residuals. Hence, 
# the residuals assumed to have no autocorrelation among themselves.

plot(actual, xlab="Months of 2021", ylab="Mid-cap Sector Index", 
     xlim=c(1, length(actual)), ylim=c(15000,30000), lwd=2, lty=1, 
     col="blue", type='l')
lines(predicted, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), 
       col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
title("Forecasting of the Mid-cap Sector Index Using Method II")


################################################################################ 
#                Method 3: Trend HoltWinters + Past Seasonality                #
################################################################################
library(forecast)
mc <- scan("midcap_2010_2021.txt")
mc <- mc[1:132]
mc_ts <- ts(mc_train, frequency=12, start=c(2010,1))
mc_ts_components <- decompose(mc_ts)
trend_trng <- mc_ts_components$trend
seasonality_trng <- mc_ts_components$seasonal
seasonality_trng <- round(seasonality_trng)
seasonality_trng


trend_series <- ts(trend_trng, frequency=12, start=c(2010,1))
trend_series <- na.omit(trend_series)
trend_series_hw <- HoltWinters(trend_series, gamma=FALSE)
trend_series_forecasts <- forecast:::forecast.HoltWinters(trend_series_hw, h=12)
trend_series_forecasts

predicted_trend <- scan("Method_3/forecasted_trend.txt")
predicted_trend <- round(predicted_trend)
seasonal_trng <- scan("Method_3/seasonal_trng.txt")

pred_trend_plus_seasonality <- predicted_trend + seasonal_trng
pred_trend_plus_seasonality

mc <- scan("midcap_2010_2021.txt")
mc_total_ts <- ts(mc, frequency=12, start=c(2010,1))
mc_ts_components <- decompose(mc_total_ts)
trend_actual <- mc_ts_components$trend
trend_actual <- round(trend_actual)
trend_actual
seasonal_actual <- mc_ts_components$seasonal
seasonal_actual <- round(seasonal_actual)
seasonal_actual
trend_plus_seasonaity_actual <- trend_actual + seasonal_actual
trend_plus_seasonaity_actual

library(Metrics)
actual <- trend_plus_seasonaity_actual[127:138]
actual
predicted <- pred_trend_plus_seasonality
predicted
x <- rmse(actual,predicted)
x
y <- mean(actual)
y
z <- (x/y)*100
z
t <- mape(actual,predicted)*100
t
error <- abs((actual-predicted)/actual)*100
error

plot(actual, xlab="Months of 2021", ylab="Mid-cap Sector Index", 
     xlim=c(1, length(actual)), ylim=c(10000,30000), lwd=2, lty=1, 
     col="blue", type='l')
lines(predicted, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), 
       col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
title("Forecasting of the Mid-cap Sector Index Using Method III")


################################################################################
#           Method 4: ARIMA with a Forecast Horizon = 12 Months                #
################################################################################

library(forecast)
mc<- scan("midcap_2010_2021.txt")
mc_train <- mc[1:132]
library(tseries)
adf.test(mc_train)
# H0 has a p-value of 0.5325.H0 assumes that the series is not stationary.
# This implies that the series is not a stationary time-series.
mc_train_diff1 <- diff(mc_train, differences=1)
adf.test(mc_train_diff1)
# The p-value (0.01) of H0 implies that the first-order difference series is a
# stationary series.
kpss.test(mc_train)
# H0 of KPSS test assumes a stationary series. As H0 fails to gather enough
# support (0.01), the series can be assume to be not stationary.
kpss.test(mc_train_diff1)
# HO gains enough support (p-value is 0.1) and the first-order difference 
# series is assumed to be a stationary series.

acf(mc_train_diff1, lag.max=24, 
    main = "ACF Plot of First Order Difference of the Mid-cap Sector Index Time Series")
acf(mc_train_diff1, lag.max=24, plot=FALSE)

pacf(mc_train_diff1, lag.max=24, main = "PACF Plot of First Order Difference of the Mid-cap Sector Index Time Series")
pacf(mc_train_diff1, lag.max=20, plot=FALSE)

plot.ts(mc_train_diff1)

library(forecast)
auto.arima(mc_train, seasonal=TRUE)

mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima

acf(mc_arima$residuals, lag.max=24, lwd = 1.5, main = "ACF Plot of the Residuals for Method IV")
acf(mc_arima$residuals, lag.max=24, plot=FALSE)
Box.test(mc_arima$residuals, lag=24, type="Ljung-Box")
# Ho that assumes the residuals to be uncorrelated gains enough support.
# The p-value of H0 is 0.2814

mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=12)
mc_arima_forecasts_outsample

library(Metrics)
actual <- mc[133:144]
actual <- round(actual)
actual
predicted <- scan("Method_4/predicted_2021_method_IV.txt")
predicted <- round(predicted)
predicted
x <- rmse(actual,predicted)
x
y <- mean(actual)
y
z <- (x/y)*100
z
t <- mape(actual,predicted)*100
t
error <- ((actual-predicted)/actual)*100
error


plot(actual, xlab="Months of 2021", ylab="Mid-cap Sector Index", 
     xlim=c(1, length(actual)), ylim=c(15000,30000), lwd=2, lty=1, 
     col="blue", type='l')
lines(predicted, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), 
       cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
title("Forecasting of the Mid-cap Sector Index Using Method IV")

################################################################################
#                    Method 5: ARIMA with Forecast Horizon = 1 month           #
################################################################################

mc <- scan("midcap_2010_2021.txt")
mc_train <- mc[1:132]

library(forecast)
auto.arima(mc_train, seasonal=TRUE)

mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Feb 2021
mc_train <- mc[1:133]
auto.arima(mc_train, seasonal=TRUE)

mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Mar 2021
mc_train <- mc[1:134]
auto.arima(mc_train)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Apr 2021
mc_train <- mc[1:135]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for May 2021
mc_train <- mc[1:136]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Jun 2021
mc_train <- mc[1:137]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Jul 2021
mc_train <- mc[1:138]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Aug 2021
mc_train <- mc[1:139]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Sep 2021
mc_train <- mc[1:140]
auto.arima(mc_train)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Oct 2021
mc_train <- mc[1:141]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Nov 2021
mc_train <- mc[1:142]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample

# Forecasting for Dec 2021
mc_train <- mc[1:143]
auto.arima(mc_train, seasonal=TRUE)
mc_arima <- Arima(mc_train, order=c(0,1,0), include.drift=TRUE)
mc_arima
mc_arima_forecasts_outsample <- forecast:::forecast.Arima(mc_arima, h=1)
mc_arima_forecasts_outsample



library(Metrics)
actual <- mc[133:144]
predicted <- scan("Method_5/predicted_midcap_index_2021_method_V.txt")
predicted <- round(predicted)
predicted
x <- rmse(actual,predicted)
x
y <- mean(actual)
y
z <- (x/y)*100
z
t <- mape(actual,predicted)*100
t
error <- abs((actual-predicted)/actual)*100
error

residuals <- (actual-predicted) 
acf(residuals, lag.max=12, lwd = 1.5, 
    main = "ACF Plot of the Residuals for Method V")
acf(residuals, lag.max=12, plot=FALSE)
Box.test(residuals, lag=11, type="Ljung-Box")
# Ho assumes the residuals not autocorrelated and Ho sufficient support. 
# With a p-value of 0.5332, Ho is not rejected, and the residuals don't 
# exhibit any significant autocorrelation.

plot(actual, xlab="Months of 2021", ylab="Mid-cap Sector Index", xlim=c(1, length(actual)), ylim=c(15000,30000), lwd=2, lty=1, col="blue", type='l')
lines(predicted, lty=2, col="red", lwd=2)
legend("topleft", c("Actual Index","Predicted Index"), col=c("blue","red"), cex=0.8, lty=c(1,2), lwd=c(2,2), bty="n")
title("Forecasting of the Mid-cap Sector Index Using Method V")
